BALU PERSONAL AI ASSISTANT – Android Studio project (prototype)

இந்த project-ல் உள்ள வாராந்திர pattern:
Mon G = General 09:00–18:00
Tue B = Second 14:00–22:00
Wed A = First 06:00–14:00
Thu A/C = First 06:00–14:00 + Night 22:00–06:00
Fri C = Night 22:00–06:00
Sat ARR = Arrival; roster-ல் தொடரும்
Sun R = Rest / Week Off; roster-ல் தொடரும்

முக்கிய வரம்புகள்:
- இது Android Studio source project; APK அல்ல. இங்கு Android Gradle build tool இல்லை, எனவே install செய்யக்கூடிய APK-ஐ இங்கே compile செய்ய முடியவில்லை.
- இப்போதைய prototype notification reminder மட்டும் தருகிறது; தானாக phone call அல்லது பேசும் Tamil voice இன்னும் சேர்க்கப்படவில்லை.
- Reminder நேரம் shift தொடங்குவதற்கு முன் எத்தனை நிமிடம் என்பதை App-ல் தேர்வு செய்யலாம் (default 30 minutes).
- Android 13+ notification permission மற்றும் Android 12+ exact alarm permission தேவை.
- Thursday A/C-க்கு இரண்டு shift தொடக்கங்களுக்கும் reminder.
- ARR / R-க்கு reminder இல்லை.

APK உருவாக்க:
1. Android Studio-வில் இந்த project folder-ஐ Open செய்யவும்.
2. Gradle sync முடிக்கவும்.
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. உருவான APK-ஐ Android phone-ல் install செய்யவும்.

புதிய Update: வாரத்தின் ஏழு நாட்களிலும் தினமும் மாலை 7:00 மணிக்கு Shift Attendance பதிவு செய்ய தனி Reminder சேர்க்கப்பட்டுள்ளது. இது ARR மற்றும் R நாட்களிலும் வரும். Shift தொடக்க reminders மட்டும் அந்த நாட்களில் வராது.

Correction v1.2: ARR என்பது Arrival; R என்பது Rest / Week Off. இரண்டும் வாராந்திர Roster-ல் அப்படியே இருக்கும். எல்லா 7 நாட்களிலும் மாலை 7:00 மணிக்கு Attendance Reminder வரும். Shift-start reminders வேலை உள்ள நாட்களில் மட்டும் வரும்.
