package com.balu.personalassistant

import android.Manifest
import android.app.*
import android.content.*
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.*
import java.util.Calendar

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("balu", MODE_PRIVATE) }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ReminderReceiver.createChannel(this)
        requestNotificationPermission()
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(36, 36, 36, 36)
        }
        layout.addView(TextView(this).apply {
            text = "🤖 BALU PERSONAL AI ASSISTANT\n\nஉங்கள் வாராந்திர Shift Reminder"
            textSize = 22f
        })
        val info = TextView(this).apply {
            textSize = 16f
            text = "Monday G: General 9 AM–6 PM\nTuesday B: Second 2 PM–10 PM\nWednesday A: First 6 AM–2 PM\nThursday A/C: First 6 AM–2 PM + Night 10 PM–6 AM\nFriday C: Night 10 PM–6 AM\nSaturday ARR: Arrival\nSunday R: Rest / Week Off"
        }
        layout.addView(info)
        layout.addView(TextView(this).apply {
            text = "\nShift தொடங்குவதற்கு எத்தனை நிமிடம் முன்பு Reminder வேண்டும்?"
            textSize = 16f
        })
        val lead = EditText(this).apply {
            inputType = 2
            setText(prefs.getInt("lead", 30).toString())
            hint = "30"
        }
        layout.addView(lead)
        val save = Button(this).apply {
            text = "Save & Enable Weekly Reminders"
            setOnClickListener {
                val minutes = lead.text.toString().toIntOrNull()?.coerceIn(0, 240) ?: 30
                prefs.edit().putInt("lead", minutes).putBoolean("enabled", true).apply()
                ReminderScheduler.scheduleAll(this@MainActivity, minutes)
                Toast.makeText(this@MainActivity, "வாராந்திர Reminder அமைக்கப்பட்டது", Toast.LENGTH_LONG).show()
            }
        }
        layout.addView(save)
        val disable = Button(this).apply {
            text = "Disable Reminders"
            setOnClickListener {
                prefs.edit().putBoolean("enabled", false).apply()
                ReminderScheduler.cancelAll(this@MainActivity)
                Toast.makeText(this@MainActivity, "Reminders நிறுத்தப்பட்டன", Toast.LENGTH_SHORT).show()
            }
        }
        layout.addView(disable)
        layout.addView(TextView(this).apply {
            text = "\nகுறிப்பு: ARR (Arrival) மற்றும் R (Rest / Week Off) இரண்டும் Roster-ல் தொடரும். எல்லா 7 நாட்களிலும் மாலை 7:00 மணிக்கு Shift Attendance Reminder வரும். Shift தொடக்க Reminder வேலை உள்ள நாட்களில் மட்டும் வரும். Thursday A/C நாளில் இரண்டு Shift-களுக்கும் தனித்தனி Reminder. Android notification மற்றும் exact alarm அனுமதிகளை அனுமதிக்கவும்."
            textSize = 13f
        })
        setContentView(layout)
    }

    private fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 100)
        }
        if (Build.VERSION.SDK_INT >= 31 && !getSystemService(AlarmManager::class.java).canScheduleExactAlarms()) {
            startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM))
        }
    }
}
